import './styles.css';
import { initRouter } from './router.js';

// Initialize routing
initRouter();

